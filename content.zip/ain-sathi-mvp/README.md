# আইনসাথী MVP ⚖️

বাংলাদেশের আইন সহজ বাংলায় বোঝানো, সরকারি citation দেখানো এবং উচ্চ ঝুঁকির প্রশ্ন মানব আইনজীবীর কাছে escalation করার একটি **ইনস্টলযোগ্য mobile-first PWA prototype**।

## কী আছে

- বাংলা mobile UI ও bottom navigation
- চারটি demo legal answer flow: তালাক, চেক ডিজঅনার, গ্রেপ্তার/জামিন, চাকরি/বেতন
- সরকারি আইনভান্ডারের citation link
- risk label ও high-risk escalation
- searchable law library
- lawyer consultation demo form
- local chat history এবং offline cache
- Android/iPhone Home Screen installation support

## চালানোর নিয়ম

Python 3 থাকলে:

```bash
cd ain-sathi-mvp
python3 server.py
```

তারপর ব্রাউজারে `http://localhost:4173` খুলুন। Chrome/Edge-এ Install App অথবা ফোনে Add to Home Screen ব্যবহার করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

এটি production legal-advice system নয়। উত্তরগুলো demo content এবং সম্পূর্ণ বাংলাদেশের আইনভান্ডার নয়। বাস্তব ব্যবহারকারীর জন্য প্রকাশের আগে:

1. সরকারি আইন, সংশোধনী, গেজেট ও রায়ের versioned database তৈরি করতে হবে।
2. AI উত্তর শুধু retrieved sources থেকে তৈরি করতে হবে এবং citation verifier চালাতে হবে।
3. প্রতিটি high-risk উত্তর আইনজীবী review/escalation policy অনুসরণ করবে।
4. lawyer identity, enrolment, availability ও consultation workflow যাচাই করতে হবে।
5. authentication, encryption, consent, retention, deletion ও audit logging যুক্ত করতে হবে।
6. আইনজীবীর অনুমোদন ছাড়া AI-generated document দাখিল বা স্বাক্ষরের উপযোগী হিসেবে দেখানো যাবে না।

## Production integration point

`app.js`-এর `identifyAnswer()` বর্তমানে local demo matching করে। Production-এ এটি বদলে API call করুন:

```js
const response = await fetch('/api/v1/legal-answers', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ question, locale: 'bn-BD' })
});
const answer = await response.json();
```

`openapi.yaml`-এ প্রস্তাবিত backend contract দেওয়া আছে।
