#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse
import os

parser = argparse.ArgumentParser(description="Run the AinSathi MVP locally")
parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "4173")))
args = parser.parse_args()

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
print(f"আইনসাথী চলছে: http://localhost:{args.port}")
ThreadingHTTPServer(("0.0.0.0", args.port), SimpleHTTPRequestHandler).serve_forever()
