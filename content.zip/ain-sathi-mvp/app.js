const categories = [
  { icon: '👨‍👩‍👧', title: 'পারিবারিক আইন', subtitle: 'বিয়ে, তালাক, ভরণপোষণ' },
  { icon: '🛡️', title: 'ফৌজদারি আইন', subtitle: 'গ্রেপ্তার, জামিন, অভিযোগ' },
  { icon: '🏠', title: 'ভূমি ও সম্পত্তি', subtitle: 'দলিল, দখল, উত্তরাধিকার' },
  { icon: '💼', title: 'শ্রম আইন', subtitle: 'চাকরি, বেতন, ছাঁটাই' },
  { icon: '🏦', title: 'ব্যাংকিং ও চেক', subtitle: 'চেক ডিজঅনার, ঋণ' },
  { icon: '💻', title: 'সাইবার আইন', subtitle: 'প্রতারণা, গোপনীয়তা' }
];

const lawLibrary = [
  {
    category: 'পারিবারিক', title: 'The Muslim Family Laws Ordinance, 1961',
    number: 'Ordinance VIII of 1961', description: 'মুসলিম পারিবারিক আইন—তালাকের নোটিশ, বহুবিবাহ ও ভরণপোষণের নির্বাচিত বিধান।',
    checked: 'ডেমোতে ১১ জুলাই ২০২৬ যাচাইকৃত', source: 'https://bdlaws.minlaw.gov.bd/act-details-305.html'
  },
  {
    category: 'ব্যাংকিং', title: 'The Negotiable Instruments Act, 1881',
    number: 'Act XXVI of 1881', description: 'চেক ও অন্যান্য negotiable instrument সম্পর্কিত বিধান; ধারা ১৩৮-এ cheque dishonour-এর বিধান রয়েছে।',
    checked: 'Production-এ live verification প্রয়োজন', source: 'https://bdlaws.minlaw.gov.bd/'
  },
  {
    category: 'ফৌজদারি', title: 'The Code of Criminal Procedure, 1898',
    number: 'Act V of 1898', description: 'ফৌজদারি কার্যপ্রণালী—গ্রেপ্তার, তদন্ত, বিচার ও জামিনের প্রক্রিয়াগত বিধান।',
    checked: 'ডেমোতে ১১ জুলাই ২০২৬ যাচাইকৃত', source: 'https://bdlaws.minlaw.gov.bd/act-details-75.html'
  },
  {
    category: 'শ্রম', title: 'The Bangladesh Labour Act, 2006',
    number: 'Act XLII of 2006', description: 'শ্রমিকের চাকরির শর্ত, মজুরি, কর্মঘণ্টা, ছুটি, চাকরির অবসান ও নিরাপত্তা সম্পর্কিত বিধান।',
    checked: 'Production-এ amendments sync প্রয়োজন', source: 'https://bdlaws.minlaw.gov.bd/'
  },
  {
    category: 'পারিবারিক', title: 'The Dissolution of Muslim Marriages Act, 1939',
    number: 'Act VIII of 1939', description: 'মুসলিম নারীর আদালতের মাধ্যমে বিবাহ বিচ্ছেদের ভিত্তিসমূহ।',
    checked: 'ডেমোতে ১১ জুলাই ২০২৬ যাচাইকৃত', source: 'https://bdlaws.minlaw.gov.bd/act-details-180.html'
  }
];

const legalAnswers = [
  {
    id: 'talaq', keywords: ['তালাক', 'ডিভোর্স', 'বিবাহ বিচ্ছেদ', 'বিয়ে ভাঙ'], category: 'পারিবারিক আইন', risk: 'মধ্যম ঝুঁকি', confidence: 'Demo verified',
    title: 'তালাকের প্রাথমিক প্রক্রিয়া',
    summary: 'মুসলিম পারিবারিক আইনের ক্ষেত্রে শুধু মৌখিকভাবে তালাক বলাই প্রশাসনিক প্রক্রিয়ার শেষ নয়। সংশ্লিষ্ট চেয়ারম্যানকে লিখিত নোটিশ দেওয়া এবং স্ত্রীর কাছে কপি দেওয়ার বিধান রয়েছে।',
    law: 'The Muslim Family Laws Ordinance, 1961 — ধারা ৭',
    source: 'https://bdlaws.minlaw.gov.bd/act-305/section-13539.html',
    steps: ['তালাকের ঘোষণা ও ঘটনার তারিখ লিখে রাখুন।', 'লিখিত নোটিশ সঠিক কর্তৃপক্ষের কাছে গেছে কি না যাচাই করুন।', 'নিকাহনামা, নোটিশ ও প্রাপ্তির প্রমাণ সংরক্ষণ করুন।', 'দেনমোহর, ভরণপোষণ বা সন্তানের বিষয় থাকলে পারিবারিক আইনজীবীর পরামর্শ নিন।'],
    warning: 'ব্যক্তিগত ধর্মীয় পরিচয়, নিকাহনামার শর্ত ও ঘটনার তথ্য অনুযায়ী ফল ভিন্ন হতে পারে।'
  },
  {
    id: 'cheque', keywords: ['চেক', 'ডিজঅনার', 'বাউন্স', 'ব্যাংক চেক'], category: 'ব্যাংকিং ও চেক', risk: 'সময়সীমা সংবেদনশীল', confidence: 'Needs date verification',
    title: 'চেক ডিজঅনার হলে প্রাথমিক করণীয়',
    summary: 'চেক প্রত্যাখ্যাত হলে cheque, ব্যাংক return memo এবং সংশ্লিষ্ট লেনদেনের প্রমাণ খুব গুরুত্বপূর্ণ। আইনি নোটিশ ও মামলা দায়েরের সময়সীমা ঘটনাগুলোর তারিখের ওপর নির্ভর করে।',
    law: 'The Negotiable Instruments Act, 1881 — ধারা ১৩৮',
    source: 'https://bdlaws.minlaw.gov.bd/',
    steps: ['মূল চেক ও ব্যাংকের return memo নিরাপদে রাখুন।', 'চেক দেওয়ার কারণ প্রমাণ করে এমন চুক্তি, রসিদ বা বার্তা সংগ্রহ করুন।', 'চেক উপস্থাপন, ফেরত ও নোটিশের তারিখের timeline তৈরি করুন।', 'সময়সীমার কারণে দ্রুত banking/NI Act বিষয়ে অভিজ্ঞ আইনজীবীর কাছে নথি দেখান।'],
    warning: 'এই demo নির্দিষ্ট সময়সীমা গণনা করছে না। ভুল তারিখে পদক্ষেপ নিলে দাবি ক্ষতিগ্রস্ত হতে পারে।'
  },
  {
    id: 'bail', keywords: ['গ্রেপ্তার', 'জামিন', 'রিমান্ড', 'পুলিশ ধরে', 'থানায়'], category: 'ফৌজদারি আইন', risk: 'উচ্চ ঝুঁকি', confidence: 'Human review required',
    title: 'গ্রেপ্তার বা জামিনের জরুরি পরিস্থিতি',
    summary: 'জামিনযোগ্য ও অজামিনযোগ্য অপরাধে প্রক্রিয়া এক নয়। অভিযোগের ধারা, FIR/মামলা নম্বর, আদালত এবং বর্তমান procedural status না দেখে নিশ্চিত মত দেওয়া নিরাপদ নয়।',
    law: 'The Code of Criminal Procedure, 1898 — জামিন অধ্যায়, বিশেষত ধারা ৪৯৬–৪৯৮',
    source: 'https://bdlaws.minlaw.gov.bd/act-75/chapter-details-246.html?lang=bn',
    steps: ['মামলা/FIR নম্বর ও ধারাগুলো সংগ্রহ করুন।', 'গ্রেপ্তারের স্থান, সময় এবং কোন থানায় নেওয়া হয়েছে লিখে রাখুন।', 'নিকট আত্মীয় ও ফৌজদারি আইনজীবীকে দ্রুত জানান।', 'কোনো নথি না বুঝে স্বাক্ষর করার আগে আইনজীবীর সহায়তা নিন।'],
    warning: 'এটি জরুরি ও উচ্চ ঝুঁকির বিষয়। এখনই মানব আইনজীবীর সহায়তা নিন।', escalate: true
  },
  {
    id: 'job', keywords: ['চাকরি', 'বেতন', 'ছাঁটাই', 'বরখাস্ত', 'শ্রমিক', 'ওভারটাইম'], category: 'শ্রম আইন', risk: 'মধ্যম ঝুঁকি', confidence: 'Document review needed',
    title: 'চাকরি থেকে বাদ দেওয়া বা বেতন না পাওয়ার ক্ষেত্রে',
    summary: 'প্রযোজ্য প্রতিকার নির্ভর করবে আপনি আইনের সংজ্ঞায় worker কি না, নিয়োগপত্রের শর্ত, চাকরি শেষ করার ধরন এবং প্রতিষ্ঠানের প্রকৃতির ওপর।',
    law: 'The Bangladesh Labour Act, 2006 — চাকরির অবসান ও মজুরি সম্পর্কিত প্রাসঙ্গিক বিধান',
    source: 'https://bdlaws.minlaw.gov.bd/',
    steps: ['নিয়োগপত্র, ID, বেতন slip ও attendance record সংগ্রহ করুন।', 'termination letter বা মৌখিক নির্দেশের প্রমাণ রাখুন।', 'বকেয়া বেতন ও পাওনার নিজের হিসাব তৈরি করুন।', 'প্রতিষ্ঠানের HR-কে লিখিতভাবে দাবি জানান এবং শ্রম আইনজীবীর মাধ্যমে অবস্থান যাচাই করুন।'],
    warning: 'সব চাকরিজীবী বাংলাদেশ শ্রম আইনের “worker” সংজ্ঞায় পড়েন না; নথি পর্যালোচনা দরকার।'
  }
];

const lawyers = [
  { initials: 'রহ', name: 'ব্যারিস্টার রাফিদ হাসান', area: 'ফৌজদারি ও সাংবিধানিক আইন', exp: '১২ বছরের অভিজ্ঞতা' },
  { initials: 'সআ', name: 'অ্যাডভোকেট সাদিয়া আফরিন', area: 'পারিবারিক ও নারী-শিশু আইন', exp: '৯ বছরের অভিজ্ঞতা' },
  { initials: 'মক', name: 'অ্যাডভোকেট মেহেদী করিম', area: 'ভূমি, ব্যাংকিং ও চুক্তি', exp: '১৪ বছরের অভিজ্ঞতা' }
];

const suggestions = ['চেক ডিজঅনার হলে কী করব?', 'তালাকের নোটিশ কীভাবে হয়?', 'পুলিশ গ্রেপ্তার করলে করণীয়', 'বেতন না দিলে কী করব?'];
let activeFilter = 'সব';
let history = JSON.parse(localStorage.getItem('ainSathiHistory') || '[]');

const $ = (selector, parent = document) => parent.querySelector(selector);
const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];

function showScreen(name) {
  $$('.screen').forEach(s => s.classList.toggle('active', s.dataset.screen === name));
  $$('[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === name));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderCategories() {
  $('#categoryGrid').innerHTML = categories.map(c => `
    <button class="category-card" data-category="${c.title}">
      <span class="category-icon">${c.icon}</span><strong>${c.title}</strong><small>${c.subtitle}</small>
    </button>`).join('');
}

function renderPopularQuestions() {
  $('#popularQuestions').innerHTML = suggestions.map(q => `<button class="question-item" data-question="${q}"><span>${q}</span><b>→</b></button>`).join('');
  $('#suggestionRow').innerHTML = suggestions.map(q => `<button class="suggestion-chip" data-question="${q}">${q}</button>`).join('');
}

function renderLibrary() {
  const search = $('#lawSearch').value.trim().toLowerCase();
  const filtered = lawLibrary.filter(l => (activeFilter === 'সব' || l.category === activeFilter) && `${l.title} ${l.number} ${l.description}`.toLowerCase().includes(search));
  $('#lawList').innerHTML = filtered.length ? filtered.map(l => `
    <article class="law-card">
      <div class="law-card-top"><div><span class="eyebrow dark">${l.category}</span><h3>${l.title}</h3><p>${l.description}</p></div><span class="law-number">${l.number}</span></div>
      <div class="law-card-footer"><small>✓ ${l.checked}</small><a href="${l.source}" target="_blank" rel="noopener">সরকারি উৎস ↗</a></div>
    </article>`).join('') : '<div class="empty-state">কোনো আইন পাওয়া যায়নি। অন্য শব্দ দিয়ে খুঁজুন।</div>';
}

function renderFilters() {
  const filters = ['সব', ...new Set(lawLibrary.map(l => l.category))];
  $('#libraryFilters').innerHTML = filters.map(f => `<button class="filter-chip ${f === activeFilter ? 'active' : ''}" data-filter="${f}">${f}</button>`).join('');
}

function renderLawyers() {
  $('#lawyerList').innerHTML = lawyers.map(l => `
    <article class="lawyer-card"><div class="lawyer-avatar">${l.initials}</div><div><h3>${l.name}</h3><p>${l.area} · ${l.exp}</p><span class="available">● Demo availability</span></div><button data-consult="${l.area}">অনুরোধ</button></article>`).join('');
}

function identifyAnswer(question) {
  const normalized = question.toLowerCase();
  return legalAnswers.find(a => a.keywords.some(k => normalized.includes(k))) || null;
}

function addUserMessage(text, save = true) {
  const el = document.createElement('div');
  el.className = 'message user';
  el.innerHTML = `<div class="bubble"><p>${escapeHtml(text)}</p></div>`;
  $('#chatWindow').appendChild(el);
  if (save) { history.push({ role: 'user', text }); persistHistory(); }
}

function addAssistantAnswer(answer, save = true) {
  const el = document.createElement('div');
  el.className = 'message assistant';
  if (!answer) {
    el.innerHTML = `<div class="avatar">⚖</div><div class="bubble answer-card"><div class="answer-meta"><span>তথ্য অপর্যাপ্ত</span><span>Human review</span></div><strong>এই প্রশ্নের verified demo উত্তর নেই</strong><p>আপনার প্রশ্নটি গুরুত্বপূর্ণ, তবে বর্তমান MVP ডেটাসেটে নির্ভরযোগ্য আইন ও ধারা নিশ্চিত করা যায়নি। ভুল তথ্য না দিয়ে মানব আইনজীবীর কাছে পাঠানো নিরাপদ।</p><div class="answer-warning">ব্যক্তিগত পরিচয়, NID, পাসওয়ার্ড বা অপ্রয়োজনীয় সংবেদনশীল তথ্য লিখবেন না।</div><button class="escalate-inline" data-open-consultation>আইনজীবীর কাছে পাঠান</button></div>`;
  } else {
    el.innerHTML = `<div class="avatar">⚖</div><div class="bubble answer-card">
      <div class="answer-meta"><span>${answer.category}</span><span>${answer.risk}</span><span>${answer.confidence}</span></div>
      <strong>${answer.title}</strong><p>${answer.summary}</p>
      <h4>প্রযোজ্য আইন</h4><p>${answer.law}</p>
      <h4>আপনার করণীয়</h4><ul>${answer.steps.map(s => `<li>${s}</li>`).join('')}</ul>
      <div class="citation-box"><small>সরকারি citation</small><br><a href="${answer.source}" target="_blank" rel="noopener">আইনের উৎস দেখুন ↗</a></div>
      <div class="answer-warning"><strong>সতর্কতা:</strong> ${answer.warning}</div>
      ${answer.escalate ? '<button class="escalate-inline" data-open-consultation>এখনই আইনজীবীর সহায়তা নিন</button>' : ''}
    </div>`;
  }
  $('#chatWindow').appendChild(el);
  if (save) { history.push({ role: 'assistant', answerId: answer?.id || null }); persistHistory(); }
  $('#chatWindow').scrollTop = $('#chatWindow').scrollHeight;
}

function askQuestion(question) {
  const clean = question.trim();
  if (!clean) return;
  showScreen('ask');
  addUserMessage(clean);
  $('#questionInput').value = '';
  const typing = document.createElement('div');
  typing.className = 'message assistant';
  typing.innerHTML = '<div class="avatar">⚖</div><div class="typing"><i></i><i></i><i></i></div>';
  $('#chatWindow').appendChild(typing);
  $('#chatWindow').scrollTop = $('#chatWindow').scrollHeight;
  setTimeout(() => { typing.remove(); addAssistantAnswer(identifyAnswer(clean)); }, 650);
}

function restoreHistory() {
  history.forEach(item => {
    if (item.role === 'user') addUserMessage(item.text, false);
    else addAssistantAnswer(legalAnswers.find(a => a.id === item.answerId) || null, false);
  });
}

function persistHistory() { localStorage.setItem('ainSathiHistory', JSON.stringify(history.slice(-30))); }
function escapeHtml(str) { return str.replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function showToast(message) { const t=$('#toast'); t.textContent=message; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2600); }
function openConsultation(prefill = '') { if (prefill) $('#consultationArea').value = [...$('#consultationArea').options].some(o=>o.value===prefill) ? prefill : ''; $('#consultationDialog').showModal(); }

renderCategories(); renderPopularQuestions(); renderFilters(); renderLibrary(); renderLawyers(); restoreHistory();

$$('[data-nav]').forEach(b => b.addEventListener('click', () => showScreen(b.dataset.nav)));
$$('[data-go]').forEach(b => b.addEventListener('click', () => showScreen(b.dataset.go)));
document.addEventListener('click', e => {
  const q = e.target.closest('[data-question]'); if (q) askQuestion(q.dataset.question);
  const c = e.target.closest('[data-category]'); if (c) { showScreen('ask'); $('#questionInput').value = `${c.dataset.category} বিষয়ে আমার প্রশ্ন: `; $('#questionInput').focus(); }
  const f = e.target.closest('[data-filter]'); if (f) { activeFilter=f.dataset.filter; renderFilters(); renderLibrary(); }
  const consult = e.target.closest('[data-consult]'); if (consult) openConsultation(consult.dataset.consult);
  if (e.target.closest('[data-open-consultation]')) openConsultation();
});
$('#questionForm').addEventListener('submit', e => { e.preventDefault(); askQuestion($('#questionInput').value); });
$('#lawSearch').addEventListener('input', renderLibrary);
$('#openConsultation').addEventListener('click', () => openConsultation());
$('#consultationForm').addEventListener('submit', e => {
  if ($('#consultationForm').checkValidity()) {
    e.preventDefault(); $('#consultationDialog').close(); $('#consultationForm').reset(); showToast('Demo request গ্রহণ করা হয়েছে—বাস্তবে কোথাও পাঠানো হয়নি।');
  }
});
$('#clearHistory').addEventListener('click', () => { history=[]; persistHistory(); $$('#chatWindow .message').slice(1).forEach(m=>m.remove()); showToast('লোকাল chat history মুছে ফেলা হয়েছে।'); });
$('#notificationButton').addEventListener('click', () => showToast('এই MVP-তে নতুন কোনো নোটিফিকেশন নেই।'));

if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(()=>{}));
